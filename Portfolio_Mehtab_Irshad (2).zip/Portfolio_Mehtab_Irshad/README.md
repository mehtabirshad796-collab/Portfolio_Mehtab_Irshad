# Portfolio_Mehtab_Irshad

Personal portfolio website of Mehtab Irshad, built with HTML5, CSS3 and JavaScript from my own Figma design.

Live site: https://YOUR-USERNAME.github.io/Portfolio_Mehtab_Irshad/

## Folders
- index.html : all 6 sections (navbar, hero, about, skills, projects, contact and footer)
- css/style.css : colours, fonts, layout, responsive rules
- js/script.js : mobile menu, active link, contact form check
- images/ : profile photo
- files/ : CV (PDF)
