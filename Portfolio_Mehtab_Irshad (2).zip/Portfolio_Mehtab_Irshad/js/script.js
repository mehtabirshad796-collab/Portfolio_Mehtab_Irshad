/* =========================================================
   Mehtab Irshad Portfolio - script.js
   1. Mobile menu   2. Active link on scroll
   3. Contact form  4. Footer year
   ========================================================= */

// ---------- 1. Mobile menu ----------
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');

function setMenu(open) {
  nav.classList.toggle('is-open', open);
  menuToggle.classList.toggle('is-open', open);
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
}

menuToggle.addEventListener('click', () => setMenu(!nav.classList.contains('is-open')));

// Close the menu after tapping a link
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false)));

// Close the menu with the Escape key
document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

// ---------- 2. Highlight the nav link of the section on screen ----------
const links = document.querySelectorAll('.nav__link');
const sections = [...links].map(l => document.querySelector(l.getAttribute('href')));

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      links.forEach(l => l.classList.toggle('is-active', l.getAttribute('href') === '#' + entry.target.id));
    }
  });
}, { rootMargin: '-45% 0px -50% 0px' });

sections.forEach(s => s && observer.observe(s));

// ---------- 3. Contact form (validates, then opens the visitor's email app) ----------
const form = document.getElementById('contactForm');
const status = document.getElementById('formStatus');
const MY_EMAIL = 'mehtabirshad796@gmail.com';

function showError(input, message) {
  const field = input.closest('.field');
  field.classList.toggle('has-error', Boolean(message));
  field.querySelector('.field__error').textContent = message;
}

function validate() {
  let ok = true;
  const name = form.name, email = form.email, message = form.message;

  if (name.value.trim().length < 2) { showError(name, 'Please enter your name.'); ok = false; }
  else showError(name, '');

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) { showError(email, 'Please enter a valid email address.'); ok = false; }
  else showError(email, '');

  if (message.value.trim().length < 10) { showError(message, 'Please write at least 10 characters.'); ok = false; }
  else showError(message, '');

  return ok;
}

form.addEventListener('submit', e => {
  e.preventDefault();
  status.textContent = '';
  if (!validate()) return;

  const subject = encodeURIComponent('Portfolio message from ' + form.name.value.trim());
  const body = encodeURIComponent(
    form.message.value.trim() + '\n\nFrom: ' + form.name.value.trim() + ' (' + form.email.value.trim() + ')'
  );
  window.location.href = `mailto:${MY_EMAIL}?subject=${subject}&body=${body}`;
  status.textContent = 'Opening your email app. Press send there to finish.';
  form.reset();
});

// ---------- 4. Footer year ----------
document.getElementById('year').textContent = new Date().getFullYear();
